const express = require('express');
const router = express.Router();
const controller = require('../controllers/alunoController');

router.get('/', controller.index);                // HTML
router.post('/', controller.store);               // Cadastrar aluno
router.post('/edit/:id', controller.update);      // Editar aluno
router.post('/delete/:id', controller.destroy);   // Deletar aluno
router.get('/curso/:curso_id', controller.byCurso); // JSON

module.exports = router;
